﻿using Microsoft.AspNetCore.Mvc;
using santiago.Models;
namespace santiago.Controllers
{
    public class MessageController : Controller
    {
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(Message message)
        {
            ViewBag.Name = message.Name;
            ViewBag.Email = message.Email;
            ViewBag.Message = message.Content;
            return View();
        }
    }
}