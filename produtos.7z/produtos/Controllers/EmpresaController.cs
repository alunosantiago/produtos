using Microsoft.AspNetCore.Mvc;
using empresa.Models;

namespace empresa.Controllers
{
    public class EmpresaController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var empresa = new List<Empresa>{
                new Empresa{
                    Id = 1,
                    Nome = "hamiltoms",
                    Taxa = 1.5m,
                    Endereço = "Rua Brasilio Itibere 3303",
                    Fiscal = "MEI.",
                    Cnpj = 827467938,
                    Data = DateTime.Now
                },
                new Empresa{
                    Id = 1,
                    Nome = "Tec",
                    Taxa = 1.2m,
                    Endereço = "Rua Chile 310",
                    Fiscal = "SA",
                    Cnpj = 372649836,
                    Data = DateTime.Now
                },
                new Empresa{
                    Id = 1,
                    Nome = "CarSpeed",
                    Taxa = 1.6m,
                    Endereço = "Rua Brigadeiro Franco",
                    Fiscal = "SA",
                    Cnpj = 748627945,
                    Data = DateTime.Now
                }
            };


            return View(empresa);
        }
    }
}
