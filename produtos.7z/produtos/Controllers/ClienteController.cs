using Microsoft.AspNetCore.Mvc;
using cliente.Models;

namespace cliente.Controllers
{
    public class ClienteController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var clientes = new List<Cliente>{
                new Cliente{
                    Id = 5,
                    Nome = "Tulio",
                    Cpf = 928746298,
                    Telefone = 93781563,
                    Pedido = "O melhor dos produtos.",
                    Endereço = "Rua Floreano Peixoto 329",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 4,
                    Nome = "Wesley",
                    Cpf = 837625647,
                    Telefone = 93845362,
                    Pedido = "O melhor dos produtos.",
                    Endereço = "Av Agua Verde 476",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Cliente{
                    Id = 3,
                    Nome = "Sandro",
                    Cpf = 748637574,
                    Telefone = 25146723,
                    Pedido = "O melhor dos produtos.",
                    Endereço = "Rua Leonardo Leupoldino 472",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                }
            };


            return View(clientes);
        }
    }
}
