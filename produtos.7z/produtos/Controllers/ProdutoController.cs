using Microsoft.AspNetCore.Mvc;
using produto.Models;

namespace produto.Controllers
{
    public class ProdutoController : Controller
    {


        public IActionResult Index()
        {

            /*var produto = new Produto{
                Id = 1,
                Nome = "Produto X",
                Valor = 123.45m,
                Cat = "Tecnologia",
                Desc = "O melhor produto que você nunca teve."
            };*/

            var produtos = new List<Produto>{
                new Produto{
                    Id = 1,
                    Nome = "Produto X",
                    Valor = 123.45m,
                    Cat = "Tecnologia",
                    Desc = "O melhor produto que você nunca teve.",
                    Status = "ENVIADO",
                    Data = DateTime.Now
                },
                new Produto{
                    Id = 2,
                    Nome = "Produto Y",
                    Valor = 200.00m,
                    Cat = "Culinario",
                    Desc = "O melhor tênis que você nunca teve.",
                    Status = "ENVIADO"
                },
                new Produto
                {
                    Id = 3,
                    Nome = "Produto Z",
                    Valor = 20000.00m,
                    Cat = "Carro",
                    Desc = "O melhor carro que você nunca teve.",
                    Status = "CANCELADO"
                }            
            };


            return View(produtos);
        }
    }
}
